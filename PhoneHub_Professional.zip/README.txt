PHONEHUB PRO

Open index.html in a browser.

This version includes 20 real phone model names, category filters, search, sorting,
comparison, reference prices and official manufacturer links.

Important:
- Prices are time-sensitive. The site marks them as reference prices; verify before publishing.
- The phone art is a neutral placeholder. For a production site, use product images only
  when you have permission/licensing or an official affiliate feed/API that permits them.
- Before monetizing, add your own privacy policy, terms, contact page and affiliate disclosure.
- Replace official links only with verified manufacturer pages.
