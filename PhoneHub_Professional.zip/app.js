let currentCat="All";
const grid=document.getElementById("grid"), search=document.getElementById("search"), sort=document.getElementById("sort");
const a=document.getElementById("a"), b=document.getElementById("b"), table=document.getElementById("table"), count=document.getElementById("count");

function render(){
 let q=search.value.toLowerCase();
 let list=phones.filter(p=>(currentCat==="All"||p.category===currentCat)&&(`${p.name} ${p.brand} ${p.category} ${p.display} ${p.battery} ${p.camera}`.toLowerCase().includes(q)));
 if(sort.value!=="default") list.sort((x,y)=>{let px=parseInt(x.price.replace(/[^0-9]/g,""))||99999999,py=parseInt(y.price.replace(/[^0-9]/g,""))||99999999;return sort.value==="low"?px-py:py-px});
 count.textContent=`Showing ${list.length} of ${phones.length} phone models`;
 grid.innerHTML=list.map(p=>`<article class="card"><div class="pic"><span class="badge">${p.category}</span>📱</div><div class="body"><div class="brand">${p.brand}</div><h3>${p.name}</h3><div class="price">${p.price}</div><div class="muted">India reference price</div><div class="specs"><div class="spec"><span>Display</span><b>${p.display}</b></div><div class="spec"><span>Battery</span><b>${p.battery}</b></div><div class="spec"><span>Camera</span><b>${p.camera}</b></div><div class="spec"><span>Storage</span><b>${p.storage}</b></div></div><div class="actions"><a class="official" href="${p.official}" target="_blank" rel="noopener">Official ↗</a><button class="compareBtn" onclick="pick('${p.name}')">Compare</button></div></div></article>`).join("")||"<p>No phones found.</p>";
}
function fill(){let o=phones.map((p,i)=>`<option value="${i}">${p.name}</option>`).join("");a.innerHTML=o;b.innerHTML=o;b.selectedIndex=Math.min(1,phones.length-1);update();}
function update(){let x=phones[a.value],y=phones[b.value];let rows=[["Brand",x.brand,y.brand],["Category",x.category,y.category],["Display",x.display,y.display],["Battery",x.battery,y.battery],["Main camera",x.camera,y.camera],["Storage",x.storage,y.storage],["Reference price",x.price,y.price]];table.innerHTML=`<div class="comparison"><table><tr><th>Feature</th><th>${x.name}</th><th>${y.name}</th></tr>${rows.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join("")}</table></div>`}
function pick(name){a.value=phones.findIndex(p=>p.name===name);update();document.getElementById("compare").scrollIntoView({behavior:"smooth"});}
document.querySelectorAll(".cats button").forEach(btn=>btn.addEventListener("click",()=>{currentCat=btn.dataset.cat;document.querySelectorAll(".cats button").forEach(x=>x.classList.remove("active"));btn.classList.add("active");render();}));
search.addEventListener("input",render);sort.addEventListener("change",render);a.addEventListener("change",update);b.addEventListener("change",update);
document.getElementById("menuBtn").addEventListener("click",()=>document.getElementById("cats").classList.toggle("open"));
render();fill();
